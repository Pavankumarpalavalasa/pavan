# Network-Traffic-Analysis

<a href="https://zenodo.org/badge/latestdoi/118643661"><img src="https://zenodo.org/badge/118643661.svg" alt="DOI"></a>

Please cite the following papers, if you use the code as part of your research

Secure Shell (SSH) Traffic Analysis with Flow based Features Using Shallow and Deep networks: http://ieeexplore.ieee.org/document/8126143/

Evaluating Shallow and Deep networks for SSH Traffic Analysis using Flow based mechanisms: http://ieeexplore.ieee.org/document/8125851/
